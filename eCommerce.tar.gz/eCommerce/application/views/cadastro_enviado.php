<div id="homebody">
     <div id="alinhado-centro borda-base espaco-vertical">
          <h3>Seja bem-vindo � nossa loja.</h3>
          <p>Dados de cadastro recebidos.</p>
     </div>
     <div class="row-fluid">
          <p>Seu cadastro foi efetuado com sucesso.<br/>
          Voc� receber� um email para ativa��o da sua conta.<br/>
          Caso voc� n�o receba o e-mail, confira sua caixa de SPAM.<br/>
          Muito obrigado por se cadastrar.</p>
     </div>
</div>
