<div id="homebody">
 
  <div class="alinhado-centro borda-base espaco-vertical">
  
    <h3>Seja bem-vindo novamente à nossa loja.</h3>
    <p>A sua senha foi encaminhada com sucesso.</p>
  
  </div>
  
  <div class="row-fluid">
    
    <p>Sua senha foi encaminhada com sucesso.<br/>
    Caso não receba a mensagem em alguns minutos, cheque sua caixa de SPAM.<br/>
    Muito obrigado por cadastrar-se.</p>
  </div>
</div>
